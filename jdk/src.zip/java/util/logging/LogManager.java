/*
 *  2014-09-26: this file was modified by International Business Machines Corporation.
 *  Modifications Copyright 2014 IBM Corporation.
 */

/* 
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package java.util.logging;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.management.MBeanServer;
import javax.management.ObjectInstance;
import javax.management.ObjectName;

import org.apache.harmony.logging.internal.nls.Messages;

import sun.misc.JavaAWTAccess;
import sun.misc.SharedSecrets;

/**
 * <code>LogManager</code> is used to manage named <code>Logger</code>s and
 * any shared logging properties.
 * <p>
 * There is one global <code>LogManager</code> instance in the application,
 * which can be obtained by calling the static method
 * <code>LogManager.getLogManager()</code>.
 * </p>
 * <p>
 * All methods on this type can be taken as being thread safe.
 * </p>
 * <p>
 * The <code>LogManager</code> class can be specified by the
 * "java.util.logging.manager" system property. If the property is unavailable
 * or invalid <code>java.util.logging.LogManager</code> will be used by
 * default.
 * </p>
 * <p>
 * On initialization, <code>LogManager</code> reads its configuration data
 * from a properties file, which by default is the "lib/logging.properties" file
 * in the JRE directory.
 * </p>
 * <p>
 * However, two system properties can be used instead to customize the
 * initialization of the <code>LogManager</code>:
 * <ul>
 * <li>"java.util.logging.config.class"</li>
 * <li>"java.util.logging.config.file"</li>
 * </ul>
 * </p>
 * <p>
 * These properties can be set either by using the Preferences API, as a command
 * line option or by passing the appropriate system property definitions to
 * JNI_CreateJavaVM.
 * </p>
 * <p>
 * The "java.util.logging.config.class" property should specify a class name. If
 * it is set, this class will be loaded and instantiated during
 * <code>LogManager</code>'s initialization, so that this object's default
 * constructor can read the initial configuration and define properties for the
 * <code>LogManager</code>.
 * </p>
 * <p>
 * The "java.util.logging.config.file" system property can be used to specify a
 * properties file if the "java.util.logging.config.class" property has not been
 * used. This file will be read instead of the default properties file.
 * </p>
 * <p>
 * Some global logging properties are as follows:
 * <ul>
 * <li>"handlers" - a list of handler classes, separated by whitespace. These
 * classes must be subclasses of <code>Handler</code> and must have a public
 * no-argument constructor. They will be registered with the root
 * <code>Logger</code>.</li>
 * <li>"config" - a list of configuration classes, separated by whitespace.
 * These classes should also have a public no-argument default constructor,
 * which should contain all the code for applying that configuration to the
 * logging system.
 * </ul>
 * </p>
 * <p>
 * Besides global properties, properties for individual <code>Loggers</code>
 * and <code>Handlers</code> can be specified in the property files. The names
 * of these properties will start with the fully qualified name of the handler
 * or logger.
 * </p>
 * <p>
 * The <code>LogManager</code> organizes <code>Loggers</code> based on their
 * fully qualified names. For example, "x.y.z" is child of "x.y".
 * </p>
 * <p>
 * Levels for <code>Loggers</code> can be defined by properties whose name end
 * with ".level". For example, "alogger.level = 4" sets the level for the logger
 * "alogger" to 4, Any children of "alogger" will also be given the level 4
 * unless specified lower down in the properties file. The property ".level"
 * will set the log level for the root logger.
 * </p>
 * 
 */
public class LogManager {
    /*
     * ------------------------------------------------------------------- Class
     * variables
     * -------------------------------------------------------------------
     */

    // The line separator of the underlying OS
    // Use privileged code to read the line.separator system property
    private static final String lineSeparator = getPrivilegedSystemProperty("line.separator"); //$NON-NLS-1$

    private final LoggingPermission controlPermission = new LoggingPermission("control", null);

    // LoggerContext for system loggers and user loggers
    private final LoggerContext systemContext = new SystemLoggerContext();
    private final LoggerContext userContext = new LoggerContext();
    private Logger rootLogger;

    private final static Level defaultLevel = Level.INFO;

    private volatile boolean readPrimordialConfiguration;

    private boolean initializedGlobalHandlers = true;

    private boolean deathImminent;

    // the singleton instance
    static LogManager manager;

    /**
     * <p>
     * The String value of the {@link LoggingMXBean}'s ObjectName.
     * </p>
     */
    public static final String LOGGING_MXBEAN_NAME = "java.util.logging:type=Logging"; //$NON-NLS-1$

    /**
     * Get the <code>LoggingMXBean</code> instance
     * 
     * @return the <code>LoggingMXBean</code> instance
     */
    public static LoggingMXBean getLoggingMXBean() {
        try {
            final ObjectName loggingMXBeanName = new ObjectName(LOGGING_MXBEAN_NAME);
            Set loggingMXBeanSet = (Set) AccessController
                    .doPrivileged(new PrivilegedAction<Set>() {
                        public Set run() {
                            MBeanServer platformBeanServer = ManagementFactory
                                    .getPlatformMBeanServer();
                            return platformBeanServer.queryMBeans(
                                    loggingMXBeanName, null);
                        }
                    });
            if (loggingMXBeanSet.size() != 1) {
                // logging.21=There Can Be Only One logging MX bean.
                throw new AssertionError(Messages.getString("logging.21")); //$NON-NLS-1$
            }

            Iterator i = loggingMXBeanSet.iterator();
            ObjectInstance loggingMXBeanOI = (ObjectInstance) i.next();
            String lmxbcn = loggingMXBeanOI.getClassName();
            Class lmxbc = Class.forName(lmxbcn);
            final Method giMethod = lmxbc.getDeclaredMethod("getInstance");
            AccessController.doPrivileged(new PrivilegedAction<Set>() {
                public Set run() {
                    giMethod.setAccessible(true);
                    return null;
                }
            });
            
            LoggingMXBean lmxb = (LoggingMXBean) giMethod.invoke(null,
                    new Object[] {});

            return lmxb;
        } catch (Exception e) {
            // logging.22=Exception occurred while getting the logging MX bean.
            throw new AssertionError(Messages.getString("logging.22")); //$NON-NLS-1$
        }
        
    }

    // FIXME: use weak reference to avoid heap memory leak
    private Hashtable<String, WeakReference<Logger>> loggers;

    // the configuration properties
    private Properties props;

    // the property change listener
    private PropertyChangeSupport listeners;

    static {
        AccessController.doPrivileged(new PrivilegedAction<Object>() {
            public Object run() {
                String cname = null;
                try {
                    cname = System.getProperty("java.util.logging.manager");
                    if (cname != null) {
                        try {
                            Class clz = ClassLoader.getSystemClassLoader().loadClass(cname);
                            manager = (LogManager) clz.newInstance();
                        } catch (ClassNotFoundException ex) {
                            Class clz = Thread.currentThread().getContextClassLoader().loadClass(cname);
                            manager = (LogManager) clz.newInstance();
                        }
                    }
                } catch (Exception ex) {
                    System.err.println("Could not load Logmanager \"" + cname + "\"");
                    ex.printStackTrace();
                }
                if (manager == null) {
                    manager = new LogManager();
                }

                manager.rootLogger = manager.new RootLogger();
                manager.addLogger(manager.rootLogger);
                manager.systemContext.addLocalLogger(manager.rootLogger);

                // Adding the global Logger. Doing so in the Logger.<clinit>
                // would deadlock with the LogManager.<clinit>.
                Logger.global.setLogManager(manager);
                manager.addLogger(Logger.global);

                return null;
            }
        });
}

    /**
     * Default constructor. This is not public because there should be only one
     * <code>LogManager</code> instance, which can be get by
     * <code>LogManager.getLogManager(</code>. This is protected so that
     * application can subclass the object.
     */
    protected LogManager() {
        this(checkSubclassPermissions());
    }

    private LogManager(Void checked) {
        loggers = new Hashtable<String, WeakReference<Logger>>();
        props = new Properties();
        listeners = new PropertyChangeSupport(this);
        // add shutdown hook to ensure that the associated resource will be
        // freed when JVM exits
        AccessController.doPrivileged(new PrivilegedAction<Void>() {
            public Void run() {
                try {
                    Runtime.getRuntime().addShutdownHook(new Thread() {
                        @Override
                        public void run() {
                            reset();
                        }
                    });
                } catch (IllegalStateException e) {
                    // already in shutdown phase, ignore the expection
                }
                return null;
            }
        });
    }

    private static Void checkSubclassPermissions() {
        final SecurityManager sm = System.getSecurityManager();
        if (sm != null) {
            // These permission will be required by LogManager constructor,
            // in order to register the Cleaner() thread as a shutdown hook.
            // Check them here to avoid the penalty of constructing the object
            // etc...
            sm.checkPermission(new RuntimePermission("shutdownHooks"));
            sm.checkPermission(new RuntimePermission("setContextClassLoader"));
        }
        return null;
    }

    /*
     * Package private utilities Returns the line separator of the underlying
     * OS.
     */
    static String getSystemLineSeparator() {
        return lineSeparator;
    }

    /**
     * Check that the caller has <code>LoggingPermission("control")</code> so
     * that it is trusted to modify the configuration for logging framework. If
     * the check passes, just return, otherwise <code>SecurityException</code>
     * will be thrown.
     * 
     * @throws SecurityException
     *             if there is a security manager in operation and the invoker
     *             of this method does not have the required security permission
     *             <code>LoggingPermission("control")</code>
     */
    public void checkAccess() {
        checkPermission();
    }

    void checkPermission() {
        SecurityManager sm = System.getSecurityManager();
        if (sm != null)
            sm.checkPermission(controlPermission);
        }

    /**
     * Add a given logger into the hierarchical namespace. The
     * <code>Logger.addLogger()</code> factory methods call this method to add
     * newly created Logger. This returns false if a logger with the given name
     * has existed in the namespace
     * <p>
     * Note that the <code>LogManager</code> may only retain weak references
     * to registered loggers. In order to prevent <code>Logger</code> objects
     * from being unexpectedly garbage collected it is necessary for
     * <i>applications</i> to maintain references to them.
     * </p>
     * 
     * @param logger
     *            the logger to be added
     * @return true if the given logger is added into the namespace
     *         successfully, false if the logger of given name has existed in
     *         the namespace
     */
    public synchronized boolean addLogger(Logger logger) {
        final String name = logger.getName();
        if (name == null) {
            throw new NullPointerException();
        }
        drainLoggerRefQueueBounded();
        LoggerContext cx = getUserContext();
            if (cx.addLocalLogger(logger)) {
                loadLoggerHandlers(logger, name, name + ".handlers");
                return true;
            } else {
                return false;
            }
    }

    private void addToFamilyTree(Logger logger, String name) {
        Logger parent = null;
        // find parent
        int lastSeparator;
        String parentName = name;
        while ((lastSeparator = parentName.lastIndexOf('.')) != -1) {
            parentName = parentName.substring(0, lastSeparator);
            WeakReference<Logger> ref = loggers.get(parentName);
            if (ref != null) {
                parent = ref.get();
            }
            if (parent != null) {
                logger.internalSetParent(parent);
                break;
            } else if (getProperty(parentName + ".level") != null || //$NON-NLS-1$
                    getProperty(parentName + ".handlers") != null) { //$NON-NLS-1$
                parent = Logger.getLogger(parentName);
                logger.internalSetParent(parent);
                break;
            }
        }
        if (parent == null && null != loggers.get("") && null != (parent = loggers.get("").get())) { //$NON-NLS-1$
            logger.internalSetParent(parent);
        }

        // find children
        final boolean isNameEmpty = (name.length() == 0);
        final Logger thisLogger = logger;
        final String startsStr = isNameEmpty?"":name + '.';
        // find only children under the current parent (others can 
        // not be children of the new logger)
        if (parent == null) {
            // parent is root, need to check all loggers to find children.
            final Collection<WeakReference<Logger>> allLoggers = loggers.values();
            AccessController
                    .doPrivileged(new PrivilegedAction<Object>() {
                        public Object run() {
                            for (final WeakReference<Logger> ref : allLoggers) {
                                Logger child = ref.get();
                                if (null != child && null == child.getParent()
                                        && (child.getName().startsWith(startsStr))) {
                                    child.setParent(thisLogger);
                                }
                            }
                            return null;
                        }
            });
        }else{
            final List<LoggerWeakRef> childs = parent.childs;
            final Logger oldParent = parent;
            AccessController.doPrivileged(new PrivilegedAction<Object>() {
                public Object run() {
                    final List<LoggerWeakRef> toBeRemoved = new LinkedList<LoggerWeakRef>();
                    for (Iterator<LoggerWeakRef> iter = childs.iterator(); iter.hasNext();) {
                        LoggerWeakRef ref = iter.next();
                        final Logger element = ref.get();
                        if (element != null) {
                            final String elementName = element.getName();
                            if (elementName != null && elementName.startsWith(startsStr)) {
                                    element.setParent(thisLogger);
                                    toBeRemoved.add(ref);
                            }
                        }
                    }
                    // remove child as the parent has been changed
                    oldParent.childs.removeAll(toBeRemoved);
                    return null;
                }
            });
        }
    }

    /**
     * Get the logger with the given name
     * 
     * @param name
     *            name of logger
     * @return logger with given name, or null if nothing is found
     */
    public synchronized Logger getLogger(String name) {
        return getUserContext().findLogger(name);
    }

    /**
     * Get a <code>Enumeration</code> of all registered logger names
     * 
     * @return enumeration of registered logger names
     */
    public synchronized Enumeration<String> getLoggerNames() {
        return getUserContext().getLoggerNames();
    }

    /**
     * Get the global <code>LogManager</code> instance
     * 
     * @return the global <code>LogManager</code> instance
     */
    public static LogManager getLogManager() {
        if (manager != null) {
            manager.readPrimordialConfiguration();
        }
        return manager;
    }

    private void readPrimordialConfiguration() {
        if (!readPrimordialConfiguration) {
            synchronized (this) {
                if (!readPrimordialConfiguration) {
                    if (System.out == null) {
                        return;
                    }
                    readPrimordialConfiguration = true;
                    try {
                        AccessController.doPrivileged(new PrivilegedExceptionAction<Void>() {
                                public Void run() throws Exception {
                                    readConfiguration();
                                    return null;
                                }
                            });
                    } catch (Exception ex) {
                        // System.err.println("Can't read logging configuration:");
                        // ex.printStackTrace();
                    }
                }
            }
        }
    }
    /**
     * Get the value of property with given name
     * 
     * @param name
     *            the name of property
     * @return the value of property
     */
    public String getProperty(String name) {
        return props.getProperty(name);
    }

    /**
     * Re-initialize the properties and configuration. The initialization
     * process is same as the <code>LogManager</code> instantiation.
     * <p>
     * A <code>PropertyChangeEvent</code> must be fired.
     * </p>
     * 
     * @throws IOException
     *             if any IO related problems happened
     * @throws SecurityException
     *             if security manager exists and it determines that caller does
     *             not have the required permissions to perform this action
     */
    public void readConfiguration() throws IOException {
        checkPermission();

        String configClassName = System
                .getProperty("java.util.logging.config.class"); //$NON-NLS-1$
        if (null == configClassName
                || null == getInstanceByClass(configClassName)) {
            // if config class failed, check config file
            String configFile = System
                    .getProperty("java.util.logging.config.file"); //$NON-NLS-1$

            if (null == configFile) {
                // if cannot find configFile, use default logging.properties
                configFile = new StringBuilder().append(
                        System.getProperty("java.home")).append(File.separator) //$NON-NLS-1$
                        .append("lib").append(File.separator).append( //$NON-NLS-1$
                                "logging.properties").toString(); //$NON-NLS-1$
            }

            InputStream input = null;
            try {
                input = new BufferedInputStream(new FileInputStream(configFile));
                readConfiguration(input);
            } finally {
                if (input != null) {
                    try {
                        input.close();
                    } catch (Exception e) {
                        // ignore
                    }
                }
            }
        }
    }

    // use privilege code to get system property
    static String getPrivilegedSystemProperty(final String key) {
        return AccessController.doPrivileged(new PrivilegedAction<String>() {
            public String run() {
                return System.getProperty(key);
            }
        });
    }

    // use SystemClassLoader to load class from system classpath
    static Object getInstanceByClass(final String className) {
        try {
            Class<?> clazz = ClassLoader.getSystemClassLoader().loadClass(
                    className);
            return clazz.newInstance();
        } catch (Exception e) {
            try {
                Class<?> clazz = Thread.currentThread().getContextClassLoader()
                        .loadClass(className);
                return clazz.newInstance();
            } catch (Exception innerE) {
                // failed, return directly
                return null;
            }
        }

    }

    // actual initialization process from a given input stream
    private synchronized void readConfigurationImpl(InputStream ins)
            throws IOException {
        reset();

        // Load the properties
        props.load(ins);

        // parse property "config" and apply setting
        String configs = props.getProperty("config"); //$NON-NLS-1$
        if (null != configs) {
            StringTokenizer st = new StringTokenizer(configs, " "); //$NON-NLS-1$
            while (st.hasMoreTokens()) {
                String configerName = st.nextToken();
                try {
                    Class clz = ClassLoader.getSystemClassLoader().loadClass(configerName);
                    clz.newInstance();
                } catch (Exception e) {
                    System.err.println("Can't load config class \"" + configerName + "\"");
                    System.err.println("" + e);
                }
            }
        }

        // set levels for logger        
        for (LoggerContext cx : contexts()) {
            Enumeration<String> enum_ = cx.getLoggerNames();
            while (enum_.hasMoreElements()) {
                String name = enum_.nextElement();
                Logger logger = cx.findLogger(name);
                if (logger != null) {
                    String property = props.getProperty(logger.getName() + ".level"); //$NON-NLS-1$
                    if (null != property) {
                        logger.setLevel(Level.parse(property));
                    }
                }
            }
        }

        listeners.firePropertyChange(null, null, null);

        synchronized (this) {
            initializedGlobalHandlers = false;
        }
    }

    /**
     * Re-initialize the properties and configuration from the given
     * <code>InputStream</code>
     * <p>
     * A <code>PropertyChangeEvent</code> must be fired.
     * </p>
     * 
     * @param ins
     *            the input stream.
     * @throws IOException
     *             if any IO related problems happened
     * @throws SecurityException
     *             if security manager exists and it determines that caller does
     *             not have the required permissions to perform this action
     */
    public void readConfiguration(InputStream ins) throws IOException {
        checkPermission();
        readConfigurationImpl(ins);
    }

    /**
     * Reset configuration.
     * <p>
     * All handlers are closed and removed from any named loggers. All loggers'
     * level is set to null, except the root logger's level is set to
     * <code>Level.INFO</code>.
     * </p>
     * 
     * @throws SecurityException
     *             if security manager exists and it determines that caller does
     *             not have the required permissions to perform this action
     */
    public void reset() {
        checkPermission();
        synchronized (this) {
            props = new Properties();
            initializedGlobalHandlers = true;
        }
            for (LoggerContext cx : contexts()) {
                Enumeration<String> enum_ = cx.getLoggerNames();
                while (enum_.hasMoreElements()) {
                    String name = enum_.nextElement();
                    Logger logger = cx.findLogger(name);
                    if (logger != null) {
                        resetLogger(logger);
                    }
                }
            }
        }

    private List<LoggerContext> contexts() {
        List<LoggerContext> cxs = new ArrayList<LoggerContext>();
        cxs.add(systemContext);
        cxs.add(getUserContext());
        return cxs;
    }

    private void resetLogger(Logger logger) {
        // Close all the Logger's handlers.
        Handler[] targets = logger.getHandlers();
        for (int i = 0; i < targets.length; i++) {
            Handler h = targets[i];
            logger.removeHandler(h);
            try {
                h.close();
            } catch (Exception ex) {
                // Problems closing a handler?  Keep going...
            }
        }
        String name = logger.getName();
        if (name != null && name.equals("")) {
            // This is the root logger.
            logger.setLevel(defaultLevel);
        } else {
            logger.setLevel(null);
        }
    }

    /**
     * Add a <code>PropertyChangeListener</code>, which will be invoked when
     * the properties are reread.
     * 
     * @param l
     *            the <code>PropertyChangeListener</code> to be added
     * @throws SecurityException
     *             if security manager exists and it determines that caller does
     *             not have the required permissions to perform this action
     */
    public void addPropertyChangeListener(PropertyChangeListener l) {
        if (l == null) {
            throw new NullPointerException();
        }
        checkPermission();
        listeners.addPropertyChangeListener(l);
    }

    /**
     * Remove a <code>PropertyChangeListener</code>, do nothing if the given
     * listener is not found.
     * 
     * @param l
     *            the <code>PropertyChangeListener</code> to be removed
     * @throws SecurityException
     *             if security manager exists and it determines that caller does
     *             not have the required permissions to perform this action
     */
    public void removePropertyChangeListener(PropertyChangeListener l) {
        checkPermission();
        listeners.removePropertyChangeListener(l);
    }

    private final ReferenceQueue<Logger> loggerRefQueue
        = new ReferenceQueue<Logger>();

    final class LoggerWeakRef extends WeakReference<Logger> {
        private String                name;
        private LogNode               node;
        private WeakReference<Logger> parentRef;

        LoggerWeakRef(Logger logger) {
            super(logger, loggerRefQueue);

            name = logger.getName();
        }

        void dispose() {
            if (node != null) {
                node.context.removeLogger(name);
                name = null;

                node.loggerRef = null;
                node = null;
            }

            if (parentRef != null) {
                Logger parent = parentRef.get();
                if (parent != null) {
                    parent.removeChildLogger(this);
                }
                parentRef = null;
            }
        }

        void setNode(LogNode node) {
            this.node = node;
        }

        void setParentRef(WeakReference<Logger> parentRef) {
            this.parentRef = parentRef;
        }
    }

    private static class LogNode {
        HashMap<String,LogNode> children;
        LoggerWeakRef loggerRef;
        LogNode parent;
        final LoggerContext context;

        LogNode(LogNode parent, LoggerContext context) {
            this.parent = parent;
            this.context = context;
        }

        void walkAndSetParent(Logger parent) {
            if (children == null) {
                return;
            }
            Iterator<LogNode> values = children.values().iterator();
            while (values.hasNext()) {
                LogNode node = values.next();
                LoggerWeakRef ref = node.loggerRef;
                Logger logger = (ref == null) ? null : ref.get();
                if (logger == null) {
                    node.walkAndSetParent(parent);
                } else {
                    doSetParent(logger, parent);
                }
            }
        }
    }

    private static void doSetParent(final Logger logger, final Logger parent) {
        SecurityManager sm = System.getSecurityManager();
        if (sm == null) {
            logger.setParent(parent);
            return;
        } 

        AccessController.doPrivileged(new PrivilegedAction<Object>() {
            public Object run() {
            logger.setParent(parent);
            return null;
        }});
    }

    private static void doSetLevel(final Logger logger, final Level level) {
        SecurityManager sm = System.getSecurityManager();
        if (sm == null) {
            logger.setLevel(level);
            return;
        } 

        AccessController.doPrivileged(new PrivilegedAction<Object>() {
            public Object run() {
                logger.setLevel(level);
                return null;
        }});
    }


    static class LoggerContext{

        private final Hashtable<String,LoggerWeakRef> namedLoggers =
                new Hashtable<String, LoggerWeakRef>();

        private final LogNode root;

        private LoggerContext() {
            this.root = new LogNode(null, this);
        }

        Logger demandLogger(String name, String resourceBundleName) {
            return manager.demandLogger(name, resourceBundleName);
        }

        Logger demandLogger(String name) {
            return manager.demandLogger(name, null);
        }
        
        synchronized Logger findLogger(String name) {
            LoggerWeakRef ref = namedLoggers.get(name);
            if (ref == null) {
                return null;
            }
            Logger logger = ref.get();
            if (logger == null) {
                removeLogger(name);
            }
            return logger;
        }

        synchronized boolean addLocalLogger(Logger logger) {
            final String name = logger.getName();
            if (name == null) {
                throw new NullPointerException();
            }

            LoggerWeakRef ref = namedLoggers.get(name);
            if (ref != null) {
                if (ref.get() == null) {
                    removeLogger(name);
                } else {
                    return false;
                }
            }

            ref = manager.new LoggerWeakRef(logger);
            namedLoggers.put(name, ref);

            Level level = manager.getLevelProperty(name + ".level", null);
            if (level != null) {
                doSetLevel(logger, level);
            }

            processParentHandlers(logger, name);

            LogNode node = getNode(name);
            node.loggerRef = ref;
            Logger parent = null;
            LogNode nodep = node.parent;
            while (nodep != null) {
                LoggerWeakRef nodeRef = nodep.loggerRef;
                if (nodeRef != null) {
                    parent = nodeRef.get();
                    if (parent != null) {
                        break;
                    }
                }
                nodep = nodep.parent;
            }

            if (parent != null) {
                doSetParent(logger, parent);
            }
            node.walkAndSetParent(logger);
            ref.setNode(node);
            return true;
        }

        void removeLogger(String name) {
            namedLoggers.remove(name);
        }

        synchronized Enumeration<String> getLoggerNames() {
            return namedLoggers.keys();
        }

        private void processParentHandlers(final Logger logger, final String name) {
             AccessController.doPrivileged(new PrivilegedAction<Void>() {
                 public Void run() {
                     if (logger != manager.rootLogger) {
                         boolean useParent = manager.getBooleanProperty(name + ".useParentHandlers", true);
                         if (!useParent) {
                             logger.setUseParentHandlers(false);
                         }
                     }
                     return null;
                 }
             });
            int ix = 1;
            for (;;) {
                int ix2 = name.indexOf(".", ix);
                if (ix2 < 0) {
                    break;
                }
                String pname = name.substring(0, ix2);

                if (manager.getProperty(pname + ".level") != null
                        || manager.getProperty(pname + ".handlers") != null) {
                    demandLogger(pname, null);
                }
                ix = ix2 + 1;
            }
        }

        LogNode getNode(String name) {
            if (name == null || name.equals("")) {
                return root;
            }
            LogNode node = root;
            while (name.length() > 0) {
                int ix = name.indexOf(".");
                String head;
                if (ix > 0) {
                    head = name.substring(0, ix);
                    name = name.substring(ix + 1);
                } else {
                    head = name;
                    name = "";
                }
                if (node.children == null) {
                    node.children = new HashMap<String, LogNode>();
                }
                LogNode child = node.children.get(head);
                if (child == null) {
                    child = new LogNode(node, this);
                    node.children.put(head, child);
                }
                node = child;
            }
            return node;
        }
    }

    Logger demandLogger(String name, String resourceBundleName) {
        Logger result = getLogger(name);
        if (result == null) {
            Logger newLogger = new Logger(name, resourceBundleName, false);
            do {
                if (addLogger(newLogger)) {
                    return newLogger;
                }
                result = getLogger(name);
            } while (result == null);
        }
        return result;
    }

    Logger demandSystemLogger(String name, String resourceBundleName) {
        // Add a system logger in the system context's namespace
        final Logger sysLogger = systemContext.demandLogger(name, resourceBundleName);

        // Add the system logger to the LogManager's namespace if not exist
        // so that there is only one single logger of the given name.
        // System loggers are visible to applications unless a logger of
        // the same name has been added.
        Logger logger;
        do {
            if (addLogger(sysLogger)) {
                // successfully added the new system logger
                logger = sysLogger;
            } else {
                logger = getLogger(name);
            }
        } while (logger == null);

        // LogManager will set the sysLogger's handlers via LogManager.addLogger method.
        if (logger != sysLogger && sysLogger.accessCheckedHandlers().length == 0) {
            // if logger already exists but handlers not set
            final Logger l = logger;
            AccessController.doPrivileged(new PrivilegedAction<Void>() {
                public Void run() {
                    for (Handler hdl : l.accessCheckedHandlers()) {
                        sysLogger.addHandler(hdl);
                    }
                    return null;
                }
            });
        }
        return sysLogger;
    }

    private LoggerContext getUserContext() {
        LoggerContext context = null;
        SecurityManager sm = System.getSecurityManager();
        JavaAWTAccess javaAwtAccess = SharedSecrets.getJavaAWTAccess();
        if (sm != null && javaAwtAccess != null) {
            synchronized (javaAwtAccess) {
                Object ecx = javaAwtAccess.getExecutionContext();
                if (ecx == null) {
                    ecx = javaAwtAccess.getContext();
                }
                context = (LoggerContext)javaAwtAccess.get(ecx, LoggerContext.class);
                if (context == null) {
                    if (javaAwtAccess.isMainAppContext()) {
                        context = userContext;
                    } else {
                        context = new LoggerContext();
                        context.addLocalLogger(manager.rootLogger);
                    }
                    javaAwtAccess.put(ecx, LoggerContext.class, context);
                }
            }
        } else {
            context = userContext;
        }
        return context;
    }

    static class SystemLoggerContext extends LoggerContext {
        Logger demandLogger(String name, String resourceBundleName) {
            Logger result = findLogger(name);
            if (result == null) {
                Logger newLogger = new Logger(name, resourceBundleName, true);
                do {
                    if (addLocalLogger(newLogger)) {
                        result = newLogger;
                     } else {
                         result = findLogger(name);
                    }
                } while (result == null);
            }

            return result;
        }
    }

    private final static int MAX_ITERATIONS = 400;
    final synchronized void drainLoggerRefQueueBounded() {
        for (int i = 0; i < MAX_ITERATIONS; i++) {
            if (loggerRefQueue == null) {
                break;
            }

            WeakReference<Logger> dummy = (WeakReference<Logger>) loggerRefQueue.poll();
            LoggerWeakRef ref = (LoggerWeakRef) dummy;
            if (ref == null) {
                break;
            }
            ref.dispose();
        }
    }

    Level getLevelProperty(String name, Level defaultValue) {
        String val = getProperty(name);
        if (val == null) {
            return defaultValue;
        }
        Level l = Level.findLevel(val.trim());
        return l != null ? l : defaultValue;
    }

    private void loadLoggerHandlers(final Logger logger, final String name,
            final String handlersPropertyName) {
        AccessController.doPrivileged(new PrivilegedAction<Object>() {
            public Object run() {
                String names[] = parseClassNames(handlersPropertyName);
                for (int i = 0; i < names.length; i++) {
                    String word = names[i];
                    try {
                        Handler hdl = (Handler) getInstanceByClass(word);
                        String levs = getProperty(word + ".level");
                        if (levs != null) {
                            Level l = Level.findLevel(levs);
                            if (l != null) {
                                hdl.setLevel(l);
                            } else {
                                System.err.println("Can't set level for " + word);
                            }
                        }
                        logger.addHandler(hdl);
                    } catch (Exception ex) {
                        System.err.println("Can't load log handler \"" + word + "\"");
                        System.err.println("" + ex);
                        ex.printStackTrace();
                    }
                }
                return null;
            }
        });
    }

    boolean getBooleanProperty(String name, boolean defaultValue) {
    String val = getProperty(name);
    if (val == null) {
        return defaultValue;
    }
    val = val.toLowerCase();
    if (val.equals("true") || val.equals("1")) {
        return true;
    } else if (val.equals("false") || val.equals("0")) {
        return false;
    }
        return defaultValue;
    }

    private String[] parseClassNames(String propertyName) {
    String hands = getProperty(propertyName);
    if (hands == null) {
        return new String[0];
    }
    hands = hands.trim();
    int ix = 0;
    Vector<String> result = new Vector<String>();
    while (ix < hands.length()) {
        int end = ix;
        while (end < hands.length()) {
        if (Character.isWhitespace(hands.charAt(end))) {
            break;
        }
        if (hands.charAt(end) == ',') {
            break;
        }
        end++;
        }
        String word = hands.substring(ix, end);
        ix = end+1;
        word = word.trim();
        if (word.length() == 0) {
        continue;
        }
        result.add(word);
    }
    return result.toArray(new String[result.size()]);
    }

    private final class RootLogger extends Logger {

        private RootLogger() {
            super("", null, true);
            setLevel(defaultLevel);
        }

        @Override
        public void log(LogRecord record) {
            initializeGlobalHandlers();
            super.log(record);
        }

        @Override
        public void addHandler(Handler h) {
            initializeGlobalHandlers();
            super.addHandler(h);
        }

        @Override
        public void removeHandler(Handler h) {
            initializeGlobalHandlers();
            super.removeHandler(h);
        }

        @Override
        Handler[] accessCheckedHandlers() {
            initializeGlobalHandlers();
            return super.accessCheckedHandlers();
        }
    }
    
    private synchronized void initializeGlobalHandlers() {
    if (initializedGlobalHandlers) {
        return;
    }

    initializedGlobalHandlers = true;

    if (deathImminent) {
        return;
    }
        loadLoggerHandlers(rootLogger, null, "handlers");
    }
}
