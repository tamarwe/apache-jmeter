/*
 *  2014-09-12: this file was modified by International Business Machines Corporation.
 *  Modifications Copyright 2014 IBM Corporation.
 */

/*
 *  Licensed to the Apache Software Foundation (ASF) under one or more
 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package java.beans;

import java.awt.Choice;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.List;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuShortcut;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.ScrollPane;
import java.awt.SystemColor;
import java.awt.font.TextAttribute;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Date;
import java.util.Hashtable;
import java.util.IdentityHashMap;

import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.ToolTipManager;

/**
 * The <code>Encoder</code>, together with <code>PersistenceDelegate</code> s,
 * can encode an object into a series of java statements. By executing these
 * statements, a new object can be created and it will has the same state as the
 * original object which has been passed to the encoder. Here "has the same
 * state" means the two objects are indistinguishable from their public API.
 * <p>
 * The <code>Encoder</code> and <code>PersistenceDelegate</code> s do this by
 * creating copies of the input object and all objects it references. The copy
 * process continues recursively util every object in the object graph has its
 * new copy and the new version has the same state as the old version. All
 * statements used to create those new objects and executed on them during the
 * process form the result of encoding.
 * </p>
 * 
 */
public class Encoder {

    private static final Hashtable<Class<?>, PersistenceDelegate> delegates = new Hashtable<Class<?>, PersistenceDelegate>();

    private static final Hashtable<String, String> delegateRelation = new Hashtable<String, String>(); 
    
    private static final DefaultPersistenceDelegate defaultPD = new DefaultPersistenceDelegate();

    private static LangEnumPersistenceDelegate langEnumPD = null;

    private static UtilCollectionsPersistenceDelegate utilCollectionsPD = null;

    private static ArrayPersistenceDelegate arrayPD = null;

    private static ProxyPersistenceDelegate proxyPD = null;

    private static NullPersistenceDelegate nullPD = null;

    private static final ExceptionListener defaultExListener = new DefaultExceptionListener();

    private static class DefaultExceptionListener implements ExceptionListener {

        public void exceptionThrown(Exception exception) {
            System.err.println("Exception during encoding:" + exception); //$NON-NLS-1$
            System.err.println("Continue..."); //$NON-NLS-1$
        }
    }

    static {
        delegateRelation.put("java.lang.Boolean", "java.beans.PrimitiveWrapperPersistenceDelegate");
        delegateRelation.put("java.lang.Byte", "java.beans.PrimitiveWrapperPersistenceDelegate");
        delegateRelation.put("java.lang.Character", "java.beans.PrimitiveWrapperPersistenceDelegate");
        delegateRelation.put("java.lang.Double", "java.beans.PrimitiveWrapperPersistenceDelegate");
        delegateRelation.put("java.lang.Float", "java.beans.PrimitiveWrapperPersistenceDelegate");
        delegateRelation.put("java.lang.Integer", "java.beans.PrimitiveWrapperPersistenceDelegate");
        delegateRelation.put("java.lang.Long", "java.beans.PrimitiveWrapperPersistenceDelegate");
        delegateRelation.put("java.lang.Short", "java.beans.PrimitiveWrapperPersistenceDelegate");

        delegateRelation.put("java.lang.Class", "java.beans.ClassPersistenceDelegate");
        delegateRelation.put("java.lang.reflect.Field", "java.beans.FieldPersistenceDelegate");
        delegateRelation.put("java.lang.reflect.Method", "java.beans.MethodPersistenceDelegate");
        delegateRelation.put("java.lang.String", "java.beans.StringPersistenceDelegate");
        delegateRelation.put("java.lang.reflect.Proxy", "java.beans.ProxyPersistenceDelegate");

        delegateRelation.put("java.awt.Choice", "java.beans.AwtChoicePersistenceDelegate");
        delegateRelation.put("java.awt.Color", "java.beans.AwtColorPersistenceDelegate");
        delegateRelation.put("java.awt.Container", "java.beans.AwtContainerPersistenceDelegate");
        delegateRelation.put("java.awt.Component", "java.beans.AwtComponentPersistenceDelegate");
        delegateRelation.put("java.awt.Cursor", "java.beans.AwtCursorPersistenceDelegate");
        delegateRelation.put("java.awt.Dimension", "java.beans.AwtDimensionPersistenceDelegate");
        delegateRelation.put("java.awt.Font", "java.beans.AwtFontPersistenceDelegate");
        delegateRelation.put("java.awt.Insets", "java.beans.AwtInsetsPersistenceDelegate");
        delegateRelation.put("java.awt.List", "java.beans.AwtListPersistenceDelegate");
        delegateRelation.put("java.awt.Menu", "java.beans.AwtMenuPersistenceDelegate");
        delegateRelation.put("java.awt.MenuBar", "java.beans.AwtMenuBarPersistenceDelegate");
        delegateRelation.put("java.awt.MenuShortcut",
                "java.beans.AwtMenuShortcutPersistenceDelegate");
        delegateRelation.put("java.awt.Point", "java.beans.AwtPointPersistenceDelegate");
        delegateRelation.put("java.awt.Rectangle", "java.beans.AwtRectanglePersistenceDelegate");

        delegateRelation.put("java.awt.SystemColor",
                    "java.beans.AwtSystemColorPersistenceDelegate");

        delegateRelation.put("java.awt.font.TextAttribute",
                "java.beans.AwtFontTextAttributePersistenceDelegate");

        delegateRelation.put("javax.swing.Box", "java.beans.SwingBoxPersistenceDelegate");
        delegateRelation.put("javax.swing.JFrame", "java.beans.SwingJFramePersistenceDelegate");
        delegateRelation.put("javax.swing.JTabbedPane",
                "java.beans.SwingJTabbedPanePersistenceDelegate");
        delegateRelation.put("javax.swing.DefaultComboBoxModel",
                "java.beans.SwingDefaultComboBoxModelPersistenceDelegate");
        delegateRelation.put("javax.swing.ToolTipManager",
                "java.beans.SwingToolTipManagerPersistenceDelegate");
        delegateRelation.put("java.awt.ScrollPane", "java.beans.AwtScrollPanePersistenceDelegate");

        delegateRelation.put("java.util.Date", "java.beans.UtilDatePersistenceDelegate");

        delegateRelation.put("java.util.List", "java.beans.UtilListPersistenceDelegate");
        delegateRelation.put("java.util.AbstractList", "java.beans.UtilListPersistenceDelegate");

        delegateRelation.put("java.util.Collection", "java.beans.UtilCollectionPersistenceDelegate");
        delegateRelation.put("java.util.AbstractCollection", "java.beans.UtilCollectionPersistenceDelegate");

        delegateRelation.put("java.util.Map", "java.beans.UtilMapPersistenceDelegate");
        delegateRelation.put("java.util.AbstractMap", "java.beans.UtilMapPersistenceDelegate");
        delegateRelation.put("java.util.Hashtable", "java.beans.UtilMapPersistenceDelegate");
    }

    private ExceptionListener listener = defaultExListener;

    private IdentityHashMap<Object, Object> oldNewMap = new IdentityHashMap<Object, Object>();

    /**
     * Construct a new encoder.
     */
    public Encoder() {
        super();
    }

    /**
     * Clear all the new objects have been created.
     */
    void clear() {
        oldNewMap.clear();
    }

    /**
     * Gets the new copy of the given old object.
     * <p>
     * Strings are special objects which have their new copy by default, so if
     * the old object is a string, it is returned directly.
     * </p>
     * 
     * @param old
     *            an old object
     * @return the new copy of the given old object, or null if there is not
     *         one.
     */
    public Object get(Object old) {
        if (old == null || old.getClass() == String.class) {
            return old;
        }
        return oldNewMap.get(old);
    }

    /**
     * Returns the exception listener of this encoder.
     * <p>
     * An encoder always have a non-null exception listener. A default exception
     * listener is used when the encoder is created.
     * </p>
     * 
     * @return the exception listener of this encoder
     */
    public ExceptionListener getExceptionListener() {
        return listener;
    }

    /**
     * Returns a <code>PersistenceDelegate</code> for the given class type.
     * <p>
     * The <code>PersistenceDelegate</code> is determined as following:
     * <ol>
     * <li>If a <code>PersistenceDelegate</code> has been registered by calling
     * <code>setPersistenceDelegate</code> for the given type, it is returned.</li>
     * <li>If the given type is an array class, a special
     * <code>PersistenceDelegate</code> for array types is returned.</li>
     * <li>If the given type is a proxy class, a special
     * <code>PersistenceDelegate</code> for proxy classes is returned.</li>
     * <li><code>Introspector</code> is used to check the bean descriptor value
     * "persistenceDelegate". If one is set, it is returned.</li>
     * <li>If none of the above applies, the
     * <code>DefaultPersistenceDelegate</code> is returned.</li>
     * </ol>
     * </p>
     * 
     * @param type
     *            a class type
     * @return a <code>PersistenceDelegate</code> for the given class type
     */
    public PersistenceDelegate getPersistenceDelegate(Class<?> type) {
        byte[] lock = new byte[0];
        if (type == null) {
            synchronized(lock){
                if(nullPD == null){
                    nullPD = new NullPersistenceDelegate();
                }
            }
            return nullPD; // may be return a special PD?
        }

        if (Enum.class.isAssignableFrom(type)) {
            synchronized(lock){
                if(langEnumPD == null){
                    langEnumPD = new LangEnumPersistenceDelegate();
                }
            }
            return langEnumPD;
        }

        // registered delegate
        if(!delegates.containsKey(type) && (delegateRelation.containsKey(type.getName()))){
            Class delegateClass = null;
            try {
                delegateClass = Class.forName(delegateRelation.get(type.getName()));
            } catch (ClassNotFoundException e) {
                //ignore
            }
            PersistenceDelegate delegate = null;
            try {
                delegate = (PersistenceDelegate) delegateClass.newInstance();
                //put the delegate into delegates Hashtable
                delegates.put(type, delegate);
            } catch (IllegalAccessException e) {
                //ignore
            } catch (InstantiationException e) {
                //ignore
            }
        }
        
        PersistenceDelegate registeredPD = delegates.get(type);
        if (registeredPD != null) {
            return registeredPD;
        }

        if (type.getName().startsWith(
                UtilCollectionsPersistenceDelegate.CLASS_PREFIX)) {
            synchronized(lock){
                if(utilCollectionsPD == null){
                    utilCollectionsPD = new UtilCollectionsPersistenceDelegate();
                }
            }
            return utilCollectionsPD;
        }

        if (type.isArray()) {
            synchronized(lock){
                if(arrayPD == null){
                    arrayPD = new ArrayPersistenceDelegate();
                }
            }
            return arrayPD;
        }

        if (Proxy.isProxyClass(type)) {
            synchronized(lock){
                if(proxyPD == null){
                    proxyPD = new ProxyPersistenceDelegate();
                }
            }
            return proxyPD;
        }

        // check "persistenceDelegate" property
        try {
            BeanInfo beanInfo = Introspector.getBeanInfo(type);
            if (beanInfo != null) {
                PersistenceDelegate pd = (PersistenceDelegate) beanInfo
                        .getBeanDescriptor().getValue("persistenceDelegate"); //$NON-NLS-1$
                if (pd != null) {
                    return pd;
                }
            }
        } catch (Exception e) {
            // Ignored
        }

        // default persistence delegate
        return defaultPD;
    }

    /**
     * Remvoe the existing new copy of the given old object.
     * 
     * @param old
     *            an old object
     * @return the removed new version of the old object, or null if there is
     *         not one
     */
    public Object remove(Object old) {
        return oldNewMap.remove(old);
    }

    /**
     * Sets the exception listener of this encoder.
     * 
     * @param listener
     *            the exception listener to set
     */
    public void setExceptionListener(ExceptionListener listener) {
        this.listener = listener == null ? defaultExListener : listener;
    }

    /**
     * Register the <code>PersistenceDelegate</code> of the specified type.
     * 
     * @param type
     * @param delegate
     */
    public void setPersistenceDelegate(Class<?> type,
            PersistenceDelegate delegate) {
        if (type == null || delegate == null) {
            throw new NullPointerException();
        }
        delegates.put(type, delegate);
    }

    /**
     * Write an expression of old objects.
     * <p>
     * The implementation first check the return value of the expression. If
     * there exists a new version of the object, simply return.
     * </p>
     * <p>
     * A new expression is created using the new versions of the target and the
     * arguments. If any of the old objects do not have its new version yet,
     * <code>writeObject()</code> is called to create the new version.
     * </p>
     * <p>
     * The new expression is then executed to obtained a new copy of the old
     * return value.
     * </p>
     * <p>
     * Call <code>writeObject()</code> with the old return value, so that more
     * statements will be executed on its new version to change it into the same
     * state as the old value.
     * </p>
     * 
     * @param oldExp
     *            the expression to write. The target, arguments, and return
     *            value of the expression are all old objects.
     */
    public void writeExpression(Expression oldExp) {
        if (oldExp == null) {
            throw new NullPointerException();
        }
        try {
            // if oldValue exists, no operation
            Object oldValue = expressionValue(oldExp);
            if (oldValue == null || get(oldValue) != null) {
                return;
            }

            Expression newExp = (Expression) createNewStatement(oldExp);
            // relate oldValue to newValue
            try {
                oldNewMap.put(oldValue, newExp.getValue());
            } catch (IndexOutOfBoundsException e) {
                // container does not have any component, set newVal null
            }

            // force same state
            writeObject(oldValue);
        } catch (Exception e) {
            listener.exceptionThrown(new Exception(
                    "failed to write expression: " + oldExp, e)); //$NON-NLS-1$
        }
    }

    /**
     * Encode the given object into a series of statements and expressions.
     * <p>
     * The implementation simply finds the <code>PersistenceDelegate</code>
     * responsible for the object's class, and delegate the call to it.
     * </p>
     * 
     * @param o
     *            the object to encode
     */
    protected void writeObject(Object o) {
        if (o == null) {
            return;
        }
        getPersistenceDelegate(o.getClass()).writeObject(o, this);
    }

    /**
     * Write a statement of old objects.
     * <p>
     * A new statement is created by using the new versions of the target and
     * arguments. If any of the objects do not have its new copy yet,
     * <code>writeObject()</code> is called to create one.
     * </p>
     * <p>
     * The new statement is then executed to change the state of the new object.
     * </p>
     * 
     * @param oldStat
     *            a statement of old objects
     */
    public void writeStatement(Statement oldStat) {
        if (oldStat == null) {
            throw new NullPointerException();
        }
        Statement newStat = createNewStatement(oldStat);
        try {
            // execute newStat
            newStat.execute();
        } catch (Exception e) {
            listener.exceptionThrown(new Exception(
                    "failed to write statement: " + oldStat, e)); //$NON-NLS-1$
        }
    }

    Object expressionValue(Expression exp) {
        try {
            return exp == null ? null : exp.getValue();
        } catch (IndexOutOfBoundsException e) {
            return null;
        } catch (Exception e) {
            listener.exceptionThrown(new Exception(
                    "failed to excute expression: " + exp, e)); //$NON-NLS-1$
        }
        return null;
    }

    private Statement createNewStatement(Statement oldStat) {
        Object newTarget = createNewObject(oldStat.getTarget());
        Object[] oldArgs = oldStat.getArguments();
        Object[] newArgs = new Object[oldArgs.length];
        for (int index = 0; index < oldArgs.length; index++) {
            newArgs[index] = createNewObject(oldArgs[index]);
        }

        if (oldStat.getClass() == Expression.class) {
            return new Expression(newTarget, oldStat.getMethodName(), newArgs);
        } else {
            return new Statement(newTarget, oldStat.getMethodName(), newArgs);
        }
    }

    private Object createNewObject(Object old) {
        Object nu = get(old);
        if (nu == null) {
            writeObject(old);
            nu = get(old);
        }
        return nu;
    }

}
