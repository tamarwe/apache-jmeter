/*
 *  2014-09-12: this file was modified by International Business Machines Corporation.
 *  Modifications Copyright 2014 IBM Corporation.
 */

/* 
 *  Licensed to the Apache Software Foundation (ASF) under one or more 
 *  contributor license agreements.  See the NOTICE file distributed with 
 *  this work for additional information regarding copyright ownership. 
 *  The ASF licenses this file to You under the Apache License, Version 2.0 
 *  (the "License"); you may not use this file except in compliance with 
 *  the License.  You may obtain a copy of the License at 
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0 
 * 
 *  Unless required by applicable law or agreed to in writing, software 
 *  distributed under the License is distributed on an "AS IS" BASIS, 
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 *  See the License for the specific language governing permissions and 
 *  limitations under the License. 
 */

package javax.naming.ldap;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Enumeration;
import java.util.Iterator;

import javax.naming.InvalidNameException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;

import org.apache.harmony.jndi.internal.nls.Messages;
import org.apache.harmony.jndi.internal.parser.LdapRdnParser;
import org.apache.harmony.jndi.internal.parser.RdnAttribute;
import org.apache.harmony.jndi.internal.parser.RdnAttributeList;

/**
 * TODO: JavaDoc
 */
public class Rdn implements Serializable, Comparable<Object> {

    private static final long serialVersionUID = -5994465067210009656L;

    public static String escapeValue(Object val) {
        if (val == null) {
            throw new NullPointerException("val "
                    + Messages.getString("ldap.00"));
        }
        return LdapRdnParser.escapeValue(val);
    }

    public static Object unescapeValue(String val) {
        if (val == null) {
            throw new NullPointerException("val "
                    + Messages.getString("ldap.00"));
        }
        return LdapRdnParser.unescapeValue(val);
    }

    private transient RdnAttributeList list = null;

    private transient Attributes attributes = null;

    public Rdn(Attributes attrSet) throws InvalidNameException {
        if (attrSet == null) {
            throw new NullPointerException("attrSet "
                    + Messages.getString("ldap.00"));
        }
        if (attrSet.size() == 0) {
            throw new InvalidNameException("atrrSet "
                    + Messages.getString("ldap.03"));
        }

        // check all the elements to follow RI's behavior
        NamingEnumeration<? extends Attribute> ne = attrSet.getAll();
        while (ne.hasMoreElements()) {
            try {
                ne.nextElement().get();
            } catch (NamingException e) {
                // Ignored
            }
        }

        attributes = (Attributes) attrSet.clone();
        toList();
    }

    public Rdn(Rdn rdn) {
        if (rdn == null) {
            throw new NullPointerException("rdn "
                    + Messages.getString("ldap.00"));
        }

        try {
            list = (RdnAttributeList) rdn.toList().clone();
        } catch (CloneNotSupportedException e) {
            // Ignored
        }
    }

    public Rdn(String rdnString) throws InvalidNameException {
        if (rdnString == null) {
            throw new NullPointerException("rdnString "
                    + Messages.getString("ldap.00"));
        }

        if (rdnString.length() != 0) {
            list = LdapRdnParser.getListForRdn(LdapRdnParser.parse(rdnString));
        } else {
            list = new RdnAttributeList();
        }
    }

    public Rdn(String type, Object value) throws InvalidNameException {
        if (type == null) {
            throw new NullPointerException("type "
                    + Messages.getString("ldap.00"));
        }
        if (value == null) {
            throw new NullPointerException("value "
                    + Messages.getString("ldap.00"));
        }
        if (type.length() == 0) {
            throw new InvalidNameException("type "
                    + Messages.getString("ldap.04"));
        }
        if (value instanceof String && ((String) value).length() == 0) {
            throw new InvalidNameException("value "
                    + Messages.getString("ldap.04"));
        }

        attributes = new BasicAttributes(type, value, true);
        toList();
    }

    public int compareTo(Object obj) {
        if (obj == this) {
            return 0;
        }
        if (!(obj instanceof Rdn)) {
            throw new ClassCastException(Messages.getString("ldap.06")); //$NON-NLS-1$
        }

        StringBuilder sb = new StringBuilder();
        for (Enumeration<?> iterator = attributes().getAll(); iterator
                .hasMoreElements();) {
            sb.append(iterator.nextElement().toString());
            /*
             * this one does not seem necessary. Spec does not require it, if
             * there are apps that depend on commas, uncomment it
             */
            // if (iterator.hasMoreElements()) {
            // sb.append(',');
            // }
        }
        String escapedValue1 = escapeValue(sb.toString()).toLowerCase();

        sb = new StringBuilder();
        for (Enumeration<?> iterator = ((Rdn) obj).attributes().getAll(); iterator
                .hasMoreElements();) {
            sb.append(iterator.nextElement().toString());
            /*
             * this one does not seem necessary. Spec does not require it, if
             * there are apps that depend on commas, uncomment it
             */
            // if (iterator.hasMoreElements()) {
            // sb.append(',');
            // }
        }
        String escapedValue2 = escapeValue(sb.toString()).toLowerCase();

        return escapedValue1.compareTo(escapedValue2);
    }

    private Attributes attributes() {
        if (attributes != null) {
            return (Attributes) attributes;
        }
        return toAttributes();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Rdn) || this.size() != ((Rdn) obj).size()) {
            return false;
        }
        int size = list.size();
        if (size != ((Rdn) obj).list.size()) {
            return false;
        }

        for (int index = 0; index < size; index++) {
            if (!list.get(index).equals(((Rdn) obj).list.get(index))) {
                return false;
            }
        }
        return true;
    }

    public String getType() {
        return list.get(0).getID();
    }

    public Object getValue() {
        try {
            return list.get(0).get();
        } catch (NullPointerException e) {
            // Ignored
        }
        return null;
    }

    public int hashCode() {
        int hashCode = 0;
        for (Iterator<RdnAttribute> attr = list.iterator(); attr.hasNext();) {
            RdnAttribute rdnAttr = attr.next();
            hashCode += rdnAttr.getID().toLowerCase().hashCode();
            Object[] array = rdnAttr.getAll();
            for (int index = 0; index < array.length; index++) {
                Object obj = array[index];
                if (obj instanceof byte[]) {
                    obj = new String((byte[]) obj);
                }
                if (obj instanceof String) {
                    hashCode += escapeValue(((String) obj).toLowerCase())
                            .hashCode();
                } else {
                    hashCode += obj.hashCode();
                }
            }
        }
        return hashCode;
    }

    public int size() {
        int size = 0;
        for (Iterator<RdnAttribute> iter = list.iterator(); iter.hasNext();) {
            size += iter.next().size();
        }
        return size;
    }

    public Attributes toAttributes() {
        if (attributes != null) {
            return (Attributes) attributes.clone();
        }
        BasicAttributes basicAttrs = new BasicAttributes(true);
        for (Iterator<RdnAttribute> iter = list.iterator(); iter.hasNext();) {
            RdnAttribute rdnAttr = iter.next();
            BasicAttribute basicAttr = new BasicAttribute(rdnAttr.getID(),
                    false);
            Object[] array = rdnAttr.getAll();
            for (int i = 0; i < array.length; i++) {
                basicAttr.add(array[i]);
            }
            basicAttrs.put(basicAttr);
        }
        return basicAttrs;
    }

    private RdnAttributeList toList() {
        if (list != null) {
            return list;
        }
        list = new RdnAttributeList();
        NamingEnumeration<? extends Attribute> ne = attributes.getAll();
        Attribute attr;
        RdnAttribute ra;
        try {
            while (ne.hasMoreElements()) {
                attr = ne.nextElement();
                ra = new RdnAttribute(attr.getID());
                ra.add(attr.get());
                list.add(ra);
            }
        } catch (NamingException e) {
            // Ignored
        }
        return list;
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();
        for (Iterator<RdnAttribute> iter = list.iterator(); iter.hasNext();) {
            RdnAttribute element = iter.next();
            Object[] array = element.getAll();
            for (int i = 0; i < array.length; i++) {
                sb.append(element.getID());
                sb.append('=');
                sb.append(escapeValue(array[i]));

                if (i + 1 < array.length) {
                    sb.append('+');
                }
            }

            if (iter.hasNext()) {
                sb.append('+');
            }
        }
        return sb.toString();
    }

    private void readObject(ObjectInputStream ois) throws IOException,
            ClassNotFoundException, InvalidNameException {
        ois.defaultReadObject();
        String rdnString = (String) ois.readObject();
        if (rdnString == null) {
            throw new NullPointerException("rdnString "
                    + Messages.getString("ldap.00"));
        }
        if (rdnString.length() != 0) {
            list = LdapRdnParser.getListForRdn(LdapRdnParser.parse(rdnString));
        } else {
            list = new RdnAttributeList();
        }
    }

    private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
        oos.writeObject(this.toString());
    }

}
